=== Date and Time Picker ==
Contributors: trendbydesigns
Donate link: https://trendbydesigns.com/
Tags: Chrome, IE8+, FireFox, Opera, Safari #Date Picker #Time Picker
Requires at least: 3.0.1
Tested up to: 3.4
Requires PHP: 5.2.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.
 
== Description ==
 
Datetime-Picker  is a plugin which appends a pretty nice, multi-language date and time selection popup to a hidden input field using jQuery and moment.js JavaScript libraries.It is easy to use by using short code.
 
== Installation ==
 
This section describes how to install the plugin and get it working.
 
e.g.
 
1. Upload `Datetime-Picker`  floder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3.Use shortcode in page, post or in widgets. short code is [datetime]
3.If you want Date and Time in your template php file , Place `<?php echo do_shortcode('datetime'); ?>` in your templates

Shortcodes
Is [datetime]



 
== Frequently Asked Questions ==
 
 
= Do you get any problem to Install or use this plugins?
 
Answer: please contact with me ,i will fix all issue .My mail: trendbydesigns@gmail.com , you can also visite : https://trendbydesigns.com/contact/
 
== Screenshots ==
 
1. See the Demo

 
== Changelog ==
 
= 1.0 =
* A change since the previous version.
* Another change.
 
= 0.5 =
* List versions from most recent at top to oldest at bottom.
 
== Upgrade Notice ==
 
= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.
 
= 0.5 =
This version fixes a security related bug.  Upgrade immediately.
 
== Arbitrary section ==
 
You may provide arbitrary sections, in the same format as the ones above.  This may be of use for extremely complicated
plugins where more information needs to be conveyed that doesn't fit into the categories of "description" or
"installation."  Arbitrary sections will be shown below the built-in sections outlined above.
 
